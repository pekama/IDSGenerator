package pekama.ids;

import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.XfaForm;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class IDSFiller {

    private File idsFile;

    public IDSFiller(String idsPath) {
        idsFile = new File(idsPath);
    }

    private IDSFiller(File IDSFile) {
        idsFile = IDSFile;
    }

    public void fillXmlInPdf(String xmlPath, String outputPath) throws IOException {
        InputStream inputStream = new FileInputStream(xmlPath);

        fillXmlInPdf(inputStream, outputPath);
    }

    private void fillXmlInPdf(InputStream xml, String outputPath) throws IOException, FileNotFoundException {
        File output = new File(outputPath);
        if(!output.exists()) {
            output.createNewFile();
        }
        fillXmlInPdf(xml, output);
    }

    private void fillXmlInPdf(InputStream xml, File outputFile) throws IOException, FileNotFoundException {
        PdfStamper stamper = null;
        try {
            PdfReader reader = new PdfReader(idsFile.getAbsolutePath());
            stamper = new PdfStamper(reader, new FileOutputStream(outputFile), '\0', true);
            AcroFields afields = stamper.getAcroFields();
            XfaForm xfa = afields.getXfa();
            xfa.fillXfaForm(xml);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                stamper.close();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
