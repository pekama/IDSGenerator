package pekama.ids;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.*;

import static java.lang.System.exit;
import static java.lang.System.out;

public class Main {

    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException, TransformerException, COSVisitorException {

        if (args.length != 3) {
            out.println("wrong number of arguments");
            exit(1);
        }

        String originalIds = args[0];
        String xmlFilePath = args[1];
        String outputPath = args[2];

        IDSFiller filler = new IDSFiller(originalIds);

        filler.fillXmlInPdf(xmlFilePath, outputPath);

        exit(0);
    }
}
